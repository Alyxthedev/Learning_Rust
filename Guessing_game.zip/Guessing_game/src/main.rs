//made by Alyxdev
//made 25-Nov-2021
//Guessing game Rust official tutorial

//This imports the input output lib into scope from the std lib.
use std::io;
use std::cmp::Ordering;
use rand::Rng;


//fn calls the function.
//blank () shows no parameters. 
//{} is the body.
fn main() 
{

    //println! is Rust's print statement (very similar to other languages).
    println!("Guess the number!");
    println!("Please input your geuss.");

    //let calls a var
    //mut makes the variable mutable (meaning it can be changed).
    //so let mut guess will make a mutable variable named guess.
    //everything on the right of the "=" is the value bound to the variable.
    //string  creates  new instance of string which is a growable encoded bit
    //:: indicates that new is an associated function of String.
    //"new" creates a empty string.
    //so "let mut guess = String::new();" makes a empty mutable var.
    let mut guess = String::new();
    let secret_number = rand::thread_rng().gen_range(1..101);

    //takes the user input.
    io::stdin()
        //reads the user input and writes it to the guess var.
        //the &mut is refrencing the mutable var guess.
        .read_line(&mut guess)
        //the expect method will crash and display this message if read line.
        //repsonds with "err" or a negative output.
        .expect("Failed to read line");

    println!("You guessed: {}", guess);
    println!("The secret number was {}", secret_number);

    //the computer reads top to bottom.
    //this allows us to rewrite the guess variable.
    //trim removes any white space from the guess string.
    //parse turns the characters into numbers in the string value
    //you must tell rust what number type you want.
    //in this case u32 or 32 bit intiger.
    let guess: u32 = guess.trim().parse().expect("please print a NUMBER!");

    match guess.cmp(&secret_number)
    {
        
        Ordering::Less => println!("Too small!"),
        Ordering::Greater => println!("Too big!"),
        Ordering::Equal => println!("YOU WIN!!!!!"),

    }


}
